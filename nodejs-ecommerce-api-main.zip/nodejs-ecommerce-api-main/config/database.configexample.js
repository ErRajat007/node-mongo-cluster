module.exports = {
    url:'mongodb+srv://<username>:<password>@learning.eauwn.mongodb.net/<database>?retryWrites=true&w=majority'
}